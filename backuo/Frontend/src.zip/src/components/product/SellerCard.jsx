// src/components/product/SellerCard.jsx
import { Link } from "react-router-dom";
import {
  MapPin,
  MessageCircle,
  PackageCheck,
  Phone,
  ShieldCheck,
  Star,
} from "lucide-react";
import { motion } from "framer-motion";

/* ---------- Utils ---------- */
const API =
  import.meta.env.VITE_API ||
  import.meta.env.VITE_API_URL ||
  "http://localhost:5000";

const buildImg = (u) => {
  if (!u) return "/logo.png";
  if (/^https?:\/\//i.test(u)) return u;
  return `${API}/${String(u).replace(/^\/+/, "")}`;
};

/* ---------- Rating Bar Mini ---------- */
function RatingBar({ avg, total }) {
  const stars = [5, 4, 3, 2, 1];
  return (
    <div className="mt-2 space-y-1">
      {stars.map((s) => {
        const percent = Math.max(0, Math.min(100, (avg / 5) * 100 - (5 - s) * 5));
        return (
          <div key={s} className="flex items-center gap-2 text-xs text-gray-600">
            <span className="w-5 text-right">{s}★</span>
            <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-1.5 bg-amber-400 rounded-full"
                style={{ width: `${percent}%` }}
              />
            </div>
          </div>
        );
      })}
      <div className="mt-1 text-[11px] text-gray-500 text-right">
        Dựa trên {total} đánh giá
      </div>
    </div>
  );
}

/* ---------- Seller Card ---------- */
export default function SellerCard({ seller, reviewStats }) {
  const avg = Number(
    (reviewStats && reviewStats.avg) ?? seller?.avg_rating ?? 0
  );
  const total = Number(
    (reviewStats && reviewStats.count) ?? seller?.reviews_count ?? 0
  );

  return (
    <motion.div
      className="rounded-2xl border bg-orange-50/40 p-5 shadow-inner hover:shadow-lg transition"
      initial={{ opacity: 0, scale: 0.96, y: 10 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96, y: -10 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Header */}
      <div className="mb-3 flex items-center gap-3">
        <motion.img
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          src={buildImg(seller?.avatar_url)}
          alt="Seller Avatar"
          className="h-14 w-14 rounded-full border-2 border-amber-300 object-cover shadow-sm"
          onError={(e) => (e.currentTarget.src = "/logo.png")}
        />
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <Link
              to={`/profile/${seller?.id}`}
              className="truncate text-lg font-semibold text-gray-800 hover:text-orange-600"
            >
              {seller?.username || "Người bán"}
            </Link>
            <ShieldCheck
              className="h-4 w-4 text-emerald-600"
              title="Đã xác minh"
            />
          </div>
          <div className="text-sm text-gray-600 flex items-center gap-2">
            <Phone className="h-4 w-4 text-orange-500" />
            <span>{seller?.phone || "Chưa có số"}</span>
          </div>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid gap-2 text-sm text-gray-700 md:grid-cols-2 lg:grid-cols-3">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-4 w-4 text-orange-500" />
          Tỉ lệ phản hồi:{" "}
          <b>{Math.round(Number(seller?.response_rate || 0))}%</b>
        </div>
        <div className="flex items-center gap-2">
          <PackageCheck className="h-4 w-4 text-orange-500" />
          Tốc độ phản hồi:{" "}
          <b>{Math.round((seller?.response_time_sec || 0) / 60)} phút</b>
        </div>
        <div className="flex items-center gap-2">
          <Star className="h-4 w-4 text-yellow-500" />
          Đánh giá trung bình: <b>{avg.toFixed(1)}/5</b>
          <span className="text-gray-500">({total})</span>
        </div>
        <div className="md:col-span-2 lg:col-span-3 mt-1 flex items-center gap-2">
          <MapPin className="h-4 w-4 text-orange-500" />
          <span>{seller?.address || "Địa chỉ: chưa cập nhật"}</span>
        </div>
      </div>

      {/* Mini Rating Graph */}
      {total > 0 && <RatingBar avg={avg} total={total} />}

      {/* Action Buttons */}
      <div className="mt-4 flex gap-2">
        <Link
          to={`/profile/${seller?.id}`}
          className="rounded-xl border border-orange-400 px-4 py-2 text-orange-600 hover:bg-orange-50 transition"
        >
          Xem hồ sơ
        </Link>
        <Link
          to="/messages"
          className="rounded-xl bg-gradient-to-r from-orange-500 to-amber-400 px-4 py-2 font-semibold text-white hover:from-orange-600 hover:to-amber-500 transition"
        >
          Nhắn tin
        </Link>
      </div>
    </motion.div>
  );
}
