// src/pages/Messages.jsx (hoặc src/components/messages/Messages.jsx)
import api from "@/lib/api";
import { useState, useEffect, useRef, useContext, useCallback } from "react";
import { useLocation, useSearchParams } from "react-router-dom";
import { Send, Image as ImageIcon } from "lucide-react";
import { io } from "socket.io-client";
import { toast } from "react-hot-toast";
import { AuthContext } from "@/context/AuthContext";

// ===== Utils =====
const API_BASE = import.meta.env.VITE_API_URL;

function debounce(fn, wait = 300) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}
function nanoid(size = 16) {
  const chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let id = "";
  for (let i = 0; i < size; i++) id += chars[(Math.random() * chars.length) | 0];
  return id;
}

// ===== Socket singleton (but manual connect) =====
const socket = io(`${API_BASE}/chat`, {
  path: "/socket.io",
  transports: ["websocket"],
  autoConnect: false,
  withCredentials: false,
});

export default function Messages() {
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { user, token } = useContext(AuthContext);

  const sellerId = location.state?.sellerId;
  const sellerName = location.state?.sellerName;
  const urlConversationId = searchParams.get("c");

  const [conversations, setConversations] = useState([]);
  const [activeChat, setActiveChat] = useState(null);

  const [messages, setMessages] = useState([]);
  const [hasMore, setHasMore] = useState(true); // còn tin cũ
  const [loadingList, setLoadingList] = useState(true);
  const [loadingOlder, setLoadingOlder] = useState(false);

  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const bottomRef = useRef(null);
  const listRef = useRef(null);
  const prevRoomRef = useRef(null);
  const oldestIdRef = useRef(null); // cursor before_id

  // ===== Socket lifecycle =====
  useEffect(() => {
    if (!token) return;

    // attach JWT before connect
    socket.auth = { token };
    if (!socket.connected) socket.connect();

    const onConnect = () => {};
    const onConnectError = (err) => toast.error("Không thể kết nối chat");
    const onTyping = ({ conversationId, isTyping }) => {
      if (conversationId === activeChat?.conversation_id) setIsTyping(!!isTyping);
    };
    const onNewMessage = ({ message }) => {
      // Nếu là phòng đang mở → push vào cuối; ngược lại tăng unread
      if (message.conversation_id === activeChat?.conversation_id) {
        setMessages((prev) => {
          // cập nhật thay thế optimistic (client_temp_id)
          const idx = prev.findIndex((m) => m.client_temp_id && m.status === "sending");
          if (idx !== -1 && String(prev[idx].content || "") === String(message.content || "")) {
            const next = [...prev];
            next[idx] = message; // thay tin thật
            return next;
          }
          return [...prev, message];
        });
        // scroll xuống nếu đang ở gần đáy
        if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: "smooth" });
      } else {
        setConversations((prev) =>
          prev.map((c) =>
            c.conversation_id === message.conversation_id
              ? { ...c, unread_count: (c.unread_count || 0) + 1, last_message: message }
              : c
          )
        );
      }
    };
    const onRead = ({ lastMessageId }) => {
      // có thể set trạng thái 'seen' cho tin của tôi <= lastMessageId
      setMessages((prev) =>
        prev.map((m) =>
          m.sender_id === user?.id && m.id <= lastMessageId ? { ...m, seen: true } : m
        )
      );
    };

    socket.on("connect", onConnect);
    socket.on("connect_error", onConnectError);
    socket.on("typing", onTyping);
    socket.on("message:new", onNewMessage);
    socket.on("read", onRead);

    return () => {
      socket.off("connect", onConnect);
      socket.off("connect_error", onConnectError);
      socket.off("typing", onTyping);
      socket.off("message:new", onNewMessage);
      socket.off("read", onRead);
      // Không disconnect toàn bộ nếu bạn muốn socket sống xuyên trang.
      // socket.disconnect();
    };
  }, [token, activeChat?.conversation_id, user?.id]);

  // ===== Load conversation list =====
  useEffect(() => {
    const loadConversations = async () => {
      try {
        setLoadingList(true);
        const { data } = await api.get("/api/messages/conversations");
        setConversations(data || []);
        setLoadingList(false);

        // Điều hướng theo URL ?c= / state seller
        if (urlConversationId) {
          const found = data.find((c) => String(c.conversation_id) === String(urlConversationId));
          if (found) return setActiveChat(found);
        }
        if (sellerId && sellerName) {
          const ensure = await api.post("/api/messages/ensure", { other_user_id: sellerId });
          const cid = ensure.data.conversation_id;
          const exist = data.find((c) => c.conversation_id === cid);
          return setActiveChat(
            exist || {
              conversation_id: cid,
              other_user_id: sellerId,
              other_user_name: sellerName,
              unread_count: 0,
              last_message: null,
            }
          );
        }
        if (data.length) setActiveChat(data[0]);
      } catch (err) {
        setLoadingList(false);
        toast.error("Không thể tải danh sách hội thoại");
        console.error(err);
      }
    };
    if (token) loadConversations();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  // ===== Join/leave room + load messages (initial page) =====
  useEffect(() => {
    const loadMessages = async () => {
      if (!activeChat?.conversation_id) return;

      // leave room cũ
      if (prevRoomRef.current && prevRoomRef.current !== activeChat.conversation_id) {
        socket.emit("leave", { conversationId: prevRoomRef.current });
      }
      // join room mới
      socket.emit("join", { conversationId: activeChat.conversation_id });
      prevRoomRef.current = activeChat.conversation_id;

      try {
        const { data } = await api.get(
          `/api/messages/conversations/${activeChat.conversation_id}/messages?limit=50`
        );
        setMessages(data || []);
        // cập nhật cursor cũ nhất
        if (data?.length) {
          oldestIdRef.current = data[0].id; // phần tử đầu (cũ nhất do FE đã reverse)
          setHasMore(true);
          // đánh dấu đã đọc
          const lastId = data[data.length - 1].id;
          await api.post(
            `/api/messages/conversations/${activeChat.conversation_id}/read`,
            { last_message_id: lastId }
          );
          socket.emit("read", {
            conversationId: activeChat.conversation_id,
            lastMessageId: lastId,
          });
        } else {
          oldestIdRef.current = null;
          setHasMore(false);
        }

        // kéo xuống đáy
        if (bottomRef.current) {
          bottomRef.current.scrollIntoView({ behavior: "instant" });
        }
      } catch (err) {
        console.error(err);
        toast.error("Không thể tải tin nhắn");
      }
    };
    loadMessages();
  }, [activeChat?.conversation_id]);

  // ===== Load older on scroll top =====
  const onScroll = useCallback(async () => {
    if (loadingOlder || !hasMore || !activeChat?.conversation_id) return;
    const el = listRef.current;
    if (!el) return;
    if (el.scrollTop <= 120) {
      // gần đỉnh → tải trước
      try {
        setLoadingOlder(true);
        const beforeId = oldestIdRef.current;
        if (!beforeId) {
          setHasMore(false);
          setLoadingOlder(false);
          return;
        }
        const { data } = await api.get(
          `/api/messages/conversations/${activeChat.conversation_id}/messages?before_id=${beforeId}&limit=50`
        );
        if (!data || data.length === 0) {
          setHasMore(false);
          setLoadingOlder(false);
          return;
        }

        // giữ vị trí cuộn: tính chênh lệch chiều cao trước/ sau
        const prevHeight = el.scrollHeight;
        setMessages((prev) => [...data, ...prev]); // prepend
        oldestIdRef.current = data[0].id;
        // sau render, điều chỉnh scrollTop để không "nhảy"
        setTimeout(() => {
          const newHeight = el.scrollHeight;
          el.scrollTop = newHeight - prevHeight + el.scrollTop;
        }, 0);

        setLoadingOlder(false);
      } catch (err) {
        console.error(err);
        setLoadingOlder(false);
      }
    }
  }, [activeChat?.conversation_id, hasMore, loadingOlder]);

  // attach scroll listener
  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    const handler = () => onScroll();
    el.addEventListener("scroll", handler);
    return () => el.removeEventListener("scroll", handler);
  }, [onScroll]);

  // ===== Typing (debounced) =====
  const emitTyping = useCallback(
    debounce(() => {
      if (!activeChat?.conversation_id) return;
      socket.emit("typing", { conversationId: activeChat.conversation_id, isTyping: true });
      setTimeout(() => {
        socket.emit("typing", { conversationId: activeChat.conversation_id, isTyping: false });
      }, 1200);
    }, 350),
    [activeChat?.conversation_id]
  );

  // ===== Send message (optimistic) =====
  const handleSend = async () => {
    const content = newMessage.trim();
    if (!content || !activeChat) return;

    const tempId = nanoid();
    const optimistic = {
      id: -1, // tạm
      client_temp_id: tempId,
      conversation_id: activeChat.conversation_id,
      sender_id: user?.id,
      content,
      created_at: new Date().toISOString(),
      status: "sending",
    };

    setMessages((prev) => [...prev, optimistic]);
    setNewMessage("");
    setSending(true);

    try {
      const { data } = await api.post("/api/messages/send", {
        conversation_id: activeChat.conversation_id,
        content,
        type: "text",
      });
      setMessages((prev) =>
        prev.map((m) => (m.client_temp_id === tempId ? data : m))
      );
      // scroll xuống
      if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: "smooth" });
    } catch (err) {
      console.error(err);
      toast.error("Gửi tin nhắn thất bại");
      // đánh dấu failed + cho phép gửi lại
      setMessages((prev) =>
        prev.map((m) => (m.client_temp_id === tempId ? { ...m, status: "failed" } : m))
      );
    } finally {
      setSending(false);
    }
  };

  const retrySend = async (msg) => {
    if (!msg || msg.status !== "failed") return;
    const content = msg.content;
    // đặt lại trạng thái sending
    setMessages((prev) =>
      prev.map((m) => (m.client_temp_id === msg.client_temp_id ? { ...m, status: "sending" } : m))
    );
    try {
      const { data } = await api.post("/api/messages/send", {
        conversation_id: activeChat.conversation_id,
        content,
        type: "text",
      });
      setMessages((prev) =>
        prev.map((m) => (m.client_temp_id === msg.client_temp_id ? data : m))
      );
      if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: "smooth" });
    } catch (err) {
      toast.error("Gửi lại thất bại");
      setMessages((prev) =>
        prev.map((m) => (m.client_temp_id === msg.client_temp_id ? { ...m, status: "failed" } : m))
      );
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-[calc(100vh-64px)]">
      {/* Sidebar conversations */}
      <div className="md:w-1/3 border-r bg-white overflow-y-auto">
        <div className="p-4 border-b font-semibold text-lg">Hội thoại</div>
        {loadingList ? (
          <div className="p-4 text-sm text-gray-500">Đang tải...</div>
        ) : conversations.length === 0 ? (
          <div className="p-4 text-sm text-gray-500">Chưa có hội thoại.</div>
        ) : (
          conversations.map((c) => {
            const active = c.conversation_id === activeChat?.conversation_id;
            return (
              <div
                key={c.conversation_id}
                onClick={() => setActiveChat(c)}
                className={`flex items-center gap-3 px-4 py-3 cursor-pointer border-b hover:bg-gray-50 ${
                  active ? "bg-orange-50" : ""
                }`}
              >
                <img
                  src={c.other_user_avatar ? c.other_user_avatar : "/logo.png"}
                  alt=""
                  className="w-10 h-10 rounded-full bg-gray-100 object-cover"
                />
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{c.other_user_name || "Người dùng"}</div>
                  <div className="text-xs text-gray-500 truncate">
                    {c.last_message?.content || "—"}
                  </div>
                </div>
                {c.unread_count > 0 && (
                  <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">
                    {c.unread_count}
                  </span>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col bg-white">
        {activeChat ? (
          <>
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b">
              <div className="flex items-center gap-3">
                <img
                  src={activeChat.other_user_avatar ? activeChat.other_user_avatar : "/logo.png"}
                  alt=""
                  className="w-10 h-10 rounded-full bg-gray-100 object-cover"
                />
                <div className="font-semibold">{activeChat.other_user_name}</div>
              </div>
              {isTyping && (
                <div className="text-xs text-gray-500" role="status">Đang nhập…</div>
              )}
            </div>

            {/* Messages */}
            <div ref={listRef} className="flex-1 overflow-y-auto p-4 space-y-3">
              {loadingOlder && (
                <div className="text-center text-xs text-gray-400">Đang tải tin cũ…</div>
              )}
              {messages.map((m) => {
                const mine = String(m.sender_id) === String(user?.id);
                const failed = m.status === "failed";
                const sendingState = m.status === "sending";
                return (
                  <div key={m.id !== -1 ? m.id : m.client_temp_id}
                       className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[70%] px-3 py-2 rounded-lg text-sm ${
                        mine ? "bg-orange-500 text-white" : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      <div>{m.content}</div>
                      <div className={`text-[11px] mt-1 ${mine ? "text-orange-100" : "text-gray-500"}`}>
                        {new Date(m.created_at).toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" })}
                        {mine && (
                          <>
                            {" · "}
                            {sendingState ? "Đang gửi…" : failed ? "Lỗi" : m.seen ? "Đã xem" : "Đã gửi"}
                          </>
                        )}
                      </div>
                      {failed && mine && (
                        <button
                          onClick={() => retrySend(m)}
                          className="mt-1 text-[11px] underline"
                        >
                          Gửi lại
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div className="p-3 border-t flex items-center gap-2">
              <button
                type="button"
                className="p-2 rounded border text-gray-500 hover:bg-gray-50"
                title="Gửi ảnh (sẽ hỗ trợ sau)"
                disabled
              >
                <ImageIcon size={18} />
              </button>
              <input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  } else {
                    emitTyping();
                  }
                }}
                placeholder="Nhập tin nhắn…"
                className="flex-1 border rounded px-3 py-2 text-sm"
              />
              <button
                onClick={handleSend}
                disabled={sending || !newMessage.trim()}
                className="px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600 text-sm disabled:opacity-50"
              >
                <Send size={16} className="inline mr-1" /> Gửi
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500 text-sm">
            Chọn một cuộc trò chuyện để bắt đầu.
          </div>
        )}
      </div>
    </div>
  );
}
