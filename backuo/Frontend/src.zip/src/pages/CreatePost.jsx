// src/pages/posts/CreatePost.jsx
import { useEffect, useMemo, useRef, useState } from "react";
import CategoryPicker from "@/pages/CategoryPicker";
import { createPostFD } from "@/services/postApi";
import api from "@/lib/api";

const BASE_POST_FEE = 10000;
const OK_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/avif"];
const MAX_IMAGE_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_IMAGES = 6;

export default function CreatePost() {
  // ---------- State ----------
  const [step, setStep] = useState(1); // 1: Thông tin; 2: Ảnh & Voucher
  const [form, setForm] = useState({
    title: "",
    description: "",
    price: "",
    category: "", // <-- sẽ nhận ID từ CategoryPicker
    quantity: 1,
  });
  const [images, setImages] = useState([]);     // File[]
  const [previews, setPreviews] = useState([]); // objectURL[]
  const [voucherCode, setVoucherCode] = useState("");
  const [checking, setChecking] = useState(false);
  const [checkResult, setCheckResult] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const debounceRef = useRef(null);
  const checkCtrlRef = useRef(null);

  // ---------- Helpers ----------
  const update = (patch) => setForm((f) => ({ ...f, ...patch }));

  const canNext1 = useMemo(() => {
    const priceOk = Number(form.price) > 0;
    return !!form.title && !!form.category && priceOk && form.description.trim().length > 0;
  }, [form]);

  const canSubmit = useMemo(() => {
    const hasImage = images.length > 0;
    return canNext1 && hasImage && !checking && !isSubmitting;
  }, [canNext1, images.length, checking, isSubmitting]);

  // ---------- Images ----------
  const onPickImages = (fileList) => {
    const files = Array.from(fileList || []).slice(0, MAX_IMAGES);
    const valid = [];
    for (const f of files) {
      if (!OK_IMAGE_TYPES.includes(f.type)) { alert("Ảnh phải là JPEG/PNG/WebP/AVIF"); continue; }
      if (f.size > MAX_IMAGE_SIZE) { alert("Ảnh vượt quá 10MB"); continue; }
      valid.push(f);
    }
    setImages(valid);
  };

  useEffect(() => {
    // cleanup previews cũ trước khi set mới
    previews.forEach((u) => URL.revokeObjectURL(u));
    const urls = images.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [images]);

  const removeImageAt = (idx) => setImages((arr) => arr.filter((_, i) => i !== idx));

  // ---------- Voucher preview (debounce + abort) ----------
  useEffect(() => {
    if (step !== 2) return;
    if (!voucherCode) { setCheckResult(null); return; }
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      try {
        if (checkCtrlRef.current) checkCtrlRef.current.abort();
        checkCtrlRef.current = new AbortController();
        setChecking(true);
        setCheckResult(null);
        const payload = {
          code: voucherCode.trim(),
          context: "post_fee",
          base_fee: BASE_POST_FEE,
          price: Number(form.price) || 0,
          category: form.category,
        };
        const { data } = await api.post("/api/vouchers/check", payload, {
          signal: checkCtrlRef.current.signal,
        });
        setCheckResult({
          valid: data?.valid ?? true,
          price: Number(form.price) || 0,
          fee: data?.fee ?? BASE_POST_FEE,
          discount: data?.discount ?? 0,
          total:
            data?.total ??
            Math.max(
              0,
              (Number(form.price) || 0) + (data?.fee ?? BASE_POST_FEE) - (data?.discount ?? 0)
            ),
          message: data?.message || "",
        });
      } catch (e) {
        if (e?.name === "CanceledError" || e?.name === "AbortError") return;
        setCheckResult({
          valid: false,
          price: Number(form.price) || 0,
          fee: BASE_POST_FEE,
          discount: 0,
          total: Math.max(0, (Number(form.price) || 0) + BASE_POST_FEE),
          message: e?.message || "Không kiểm tra được voucher",
        });
      } finally { setChecking(false); }
    }, 480);
    return () => clearTimeout(debounceRef.current);
  }, [voucherCode, form.price, form.category, step]);

  // ---------- Submit ----------
  const submit = async (e) => {
    e.preventDefault();
    if (!canSubmit || isSubmitting) return;
    setIsSubmitting(true);
    try {
      const fd = new FormData();
      fd.append("name", String(form.title).trim());
      fd.append("description", String(form.description).trim());
      fd.append("price", String(Number(form.price)));
      fd.append("category_id", String(form.category)); // dùng ID từ CategoryPicker
      fd.append("voucher_code", voucherCode ? voucherCode.trim() : "");
      if (images[0]) fd.append("image", images[0], images[0].name || "image.jpg");

      const created = await createPostFD(fd);

      if (created?.id) window.location.href = `/product/${created.id}`;
      else window.location.href = "/myposts";
    } catch (err) {
      alert(err?.message || "Không thể đăng tin");
    } finally { setIsSubmitting(false); }
  };

  // ---------- Keydown: chỉ chặn Enter ở <form> ----------
  const onFormKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      if (step === 1 && canNext1) setStep(2);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight text-gray-900">Đăng tin sản phẩm</h1>
        <p className="text-gray-600 mt-1">Điền thông tin cơ bản, thêm ảnh và áp mã ưu đãi (nếu có).</p>
      </div>

      {/* Stepper */}
      <div className="rounded-3xl border border-gray-100 bg-white shadow p-4 mb-6">
        <div className="flex items-center justify-between">
          <StepPill index={1} label="Thông tin" active />
          <div className={`flex-1 mx-3 h-0.5 rounded-full ${step === 2 ? "bg-gradient-to-r from-amber-500 to-orange-500" : "bg-gray-200"}`} />
          <StepPill index={2} label="Ảnh & Voucher" active={step === 2} />
        </div>
      </div>

      <div className="rounded-3xl border border-gray-100 bg-white shadow">
        <form onSubmit={submit} onKeyDown={onFormKeyDown} noValidate>
          <div className="p-6 space-y-8">
            {/* STEP 1 (mounted luôn, ẩn bằng hidden) */}
            <section className={step === 1 ? "space-y-6" : "space-y-6 hidden"} aria-hidden={step !== 1}>
              <h3 className="text-lg font-semibold text-gray-800">Thông tin cơ bản</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Field id="title" label="Tiêu đề" placeholder="VD: iPhone 13 128GB"
                  value={form.title} onChange={(e) => update({ title: e.target.value })} />
                <Field id="price" type="number" min={0} label="Giá bán (VND)" placeholder="VD: 5500000"
                  value={form.price} onChange={(e) => update({ price: e.target.value })} />

                {/* Danh mục: dùng CategoryPicker */}
                <div className="md:col-span-1">
                  <CategoryPicker
                    value={form.category}
                    onChange={(id) => update({ category: id })}
                  />
                </div>

                <Field id="quantity" type="number" min={1} label="Số lượng"
                  value={form.quantity} onChange={(e) => update({ quantity: Number(e.target.value) || 1 })} />
              </div>

              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Mô tả</label>
                <textarea
                  id="description" rows={4} placeholder="Tình trạng, phụ kiện, bảo hành…"
                  value={form.description} onChange={(e) => update({ description: e.target.value })}
                  className="w-full rounded-2xl border border-gray-200 bg-white px-3 py-2 outline-none
                             focus:border-amber-400 focus:ring-2 focus:ring-amber-100 transition"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button type="button" className="px-4 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 transition"
                        onClick={() => (window.history.length ? window.history.back() : (window.location.href = "/"))}>
                  Hủy
                </button>
                <button type="button" disabled={!canNext1} onClick={() => setStep(2)}
                        className={`px-5 py-2.5 rounded-xl shadow-md transition
                          ${canNext1 ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:brightness-105"
                                     : "bg-gray-200 text-gray-500 cursor-not-allowed"}`}>
                  Tiếp tục
                </button>
              </div>
            </section>

            {/* STEP 2 */}
            <section className={step === 2 ? "space-y-8" : "space-y-8 hidden"} aria-hidden={step !== 2}>
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">Ảnh sản phẩm</h3>
                <p className="text-sm text-gray-500 mb-3">Hỗ trợ JPEG/PNG/WebP/AVIF, tối đa {MAX_IMAGES} ảnh, ≤10MB/ảnh.</p>
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="rounded-2xl border-2 border-dashed border-amber-200 bg-amber-50/60 p-5 text-center">
                    <input
                      type="file" accept="image/*" multiple
                      onChange={(e) => onPickImages(e.target.files)}
                      className="block w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0
                                 file:bg-amber-100 hover:file:bg-amber-200 file:text-gray-800 cursor-pointer"
                    />
                    <p className="text-xs text-gray-500 mt-2">Gợi ý: ảnh vuông 1:1, ≥800×800 hiển thị sắc nét.</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Xem trước</label>
                    {previews.length === 0 ? (
                      <div className="h-[140px] rounded-2xl border border-gray-200 bg-white/70 flex items-center justify-center text-sm text-gray-500">
                        Chưa chọn ảnh
                      </div>
                    ) : (
                      <div className="grid grid-cols-3 gap-2">
                        {previews.map((url, i) => (
                          <div key={i} className="relative group">
                            <img src={url} alt={`preview-${i}`} className="w-full h-24 object-cover rounded-xl border" />
                            <button type="button" onClick={() => removeImageAt(i)}
                                    className="absolute top-1 right-1 hidden group-hover:flex items-center justify-center w-6 h-6 rounded-full bg-white/90 border text-red-600 text-xs"
                                    aria-label="Xoá ảnh" title="Xoá ảnh">✕</button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800 mb-3">Voucher & phí</h3>
                  <Field id="voucher" label="Mã voucher (nếu có)" placeholder="Nhập mã..."
                         value={voucherCode} onChange={(e) => setVoucherCode(e.target.value)} />
                </div>
                <div className="rounded-3xl bg-white border border-gray-100 shadow p-5">
                  <h4 className="font-semibold text-gray-800 mb-2">Phí & Giảm trừ</h4>
                  {checking && <p className="text-sm text-amber-600 animate-pulse">Đang kiểm tra voucher…</p>}
                  {!voucherCode && <p className="text-sm text-gray-500">Nhập mã voucher (nếu có) để xem phí/giảm trừ.</p>}
                  {checkResult && (
                    <ul className="text-sm space-y-1 mt-2">
                      <li>Giá gốc: <b>{fmtVND(checkResult.price)}</b></li>
                      <li>Phí đăng tin: <b>{fmtVND(checkResult.fee)}</b></li>
                      <li>Giảm voucher: <b>-{fmtVND(checkResult.discount)}</b></li>
                      <li>Tổng thanh toán: <b>{fmtVND(checkResult.total)}</b></li>
                      {!checkResult.valid && checkResult.message && (
                        <p className="text-xs text-red-600 mt-1">{checkResult.message}</p>
                      )}
                    </ul>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <button type="button" className="px-4 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 transition"
                        onClick={() => setStep(1)}>← Quay lại</button>
                <button type="submit" disabled={!canSubmit}
                        className={`px-6 py-2.5 rounded-xl shadow-md font-medium transition 
                          ${canSubmit ? "bg-gradient-to-r from-amber-400 to-orange-400 text-white hover:brightness-105"
                                       : "bg-gray-200 text-gray-500 cursor-not-allowed"}`}>
                  {isSubmitting ? "Đang gửi…" : "Đăng tin"}
                </button>
              </div>
            </section>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ------------ Sub components ------------- */
function StepPill({ index, label, active }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold
        ${active ? "bg-amber-500 text-white shadow" : "bg-gray-200 text-gray-600"}`}>
        {index}
      </div>
      <span className={`text-sm ${active ? "text-gray-900 font-medium" : "text-gray-500"}`}>{label}</span>
    </div>
  );
}

function Field({ id, label, ...props }) {
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input
        id={id}
        autoComplete="off"
        {...props}
        className="w-full rounded-2xl border border-gray-200 bg-white px-3 py-2 outline-none
                   focus:border-amber-400 focus:ring-2 focus:ring-amber-100 transition"
      />
    </div>
  );
}

/* ------------ Utils ------------- */
function fmtVND(n) {
  if (typeof n !== "number" || Number.isNaN(n)) return "-";
  return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(n);
}
